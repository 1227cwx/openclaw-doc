# 青鱼万能搜索接口技能文档

## 概述

此接口通过协程高并发设计 。让Agent 通过 HTTP GET 请求进行搜索操作，支持多种搜索类型、语言和引擎。接口地址为 `https://search.zvzss.com/`。

**注意**:
- 所有参数名必须为小写，且仅限于允许的参数列表。 
- 返回格式为 JSON。

## 接口信息

- **方法**: GET
- **地址**: `https://search.zvzss.com/`
- **Content-Type**: application/json

## 请求参数

以下是参数的结构化 JSON 表示，便于大模型解析和使用。Agent 可以直接从此 JSON 中提取信息。

```json
{
  "parameters": [
    {
      "name": "search",
      "type": "string",
      "required": true,
      "default": null,
      "description": "搜索关键词，必须提供非空字符串",
      "examples": ["微信", "人工智能"]
    },
    {
      "name": "categories",
      "type": "string",
      "required": false,
      "default": "general",
      "description": "搜索类型，指定搜索类别",
      "examples": ["general", "images", "videos", "files", "news"],
      "constraints": "可选值: images (图片), videos (视频), files (文件/磁力链), news (新闻)"
    },
    {
      "name": "pageno",
      "type": "integer",
      "required": false,
      "default": 1,
      "description": "页码，必须为正整数(默认：1)",
      "examples": [1, 2, 3],
      "constraints": "正整数 (>=1)"
    },
    {
      "name": "language",
      "type": "string",
      "required": false,
      "default": "auto",
      "description": "搜索语言，指定结果语言(默认：auto)",
      "examples": ["auto", "zh-CN", "en-US", "ja-JP"],
      "constraints": "有效语言代码，如 auto (自动), zh-CN (中文), en-US (英语), ja-JP (日语)"
    },
    {
      "name": "time_range",
      "type": "string",
      "required": false,
      "default": "day",
      "description": "搜索内容发布时间范围(默认：day)",
      "examples": ["day", "week", "month", "year"],
      "constraints": "可选值:  week (一周内), month (一月内), year (一年内)"
    }
  ],
  "rules": {
    "allowed_names": ["search", "categories", "pageno", "language", "time_range", "engines"],
    "case_sensitive": false,
    "required_check": "search 参数不能为空",
    "value_filter": "空值参数不会包含在 URL 中",
    "additional_constraints": "所有参数名必须小写；无效参数返回 400 错误"
  }
}
```

### 参数规则
- **解析建议**: Agent 应从 JSON 的 \"parameters\" 数组中读取每个参数的细节，并严格遵守 \"constraints\"。
- **错误处理**: 如果参数不符合 constraints，接口可能返回 500 错误；Agent 需预先验证。

## 请求示例

### 示例 1: 基本搜索
```
GET /?search=微信
```
- categories: general (默认)
- 返回: 综合搜索结果 (JSON)

### 示例 2: 指定类型和页码
```
GET /?search=人工智能&categories=images&pageno=1&language=zh-CN&time_range=day
```
- 搜索图片，第一页，中文，一月内，使用 Bing 和 Google 引擎。


### 错误响应
```json
{
  "code": 400,
  "msg": "参数 search (搜索关键词) 不能为空"
}
```
或
```json
{
  "code": 400,
  "msg": "不允许的参数名: invalid_param"
}
```
或
```json
{
  "code": 500,
  "msg": "搜索请求失败: [错误详情]"
}
```

## 错误码

| 错误码 | 描述                   |
|--------|------------------------|
| 400    | 参数错误（缺失/无效） |
| 500    | 内部错误（请求失败/解析失败） |

## 使用注意事项 (For Agent)

- **参数大小写**: 必须使用小写参数名。大写或额外参数将被拒绝。
- **值验证**: Agent 应确保参数值符合可选值范围（如 time_range 仅限 day/week/month/year）。
- **异常处理**: 如果搜索失败，检查返回的 msg 字段进行重试或错误报告。

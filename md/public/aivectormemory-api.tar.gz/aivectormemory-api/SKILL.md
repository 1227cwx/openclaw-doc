# AIVectorMemory HTTP API 调用文档

## 通用说明

- **基础 URL**：`http://你的服务器:9081`
- **方法**：POST
- **Header**：`Content-Type: application/json`
- **所有请求必须包含**：`agent_tag`（你的标识(main)）

---

## 1️⃣ remember - 存入记忆

```bash
curl -X POST http://localhost:9081/remember \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "content": "记忆内容",
    "tags": ["标签1", "标签2"]
  }'
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `agent_tag` | string | ✅ | 你的标识(main) |
| `content` | string | ✅ | 记忆内容 |
| `tags` | string[] | ✅ | 标签数组 |


## 每次对话结束后（自动执行）

**判断是否需要保存记忆**，以下情况需要保存：
- 人类提供了新的配置信息（API Key、URL、模型名等）
- 解决了一个问题（踩坑记录）
- 人类表达了明确偏好（"我喜欢..."、"以后都用..."）
- 完成了重要任务（安装了某个组件、修改了某个配置）
- 人类说了项目相关的重要信息

**不需要保存**的情况：闲聊、简单问答、无实质信息的对话。

## 人类主动操作记忆

当人类说"记住..."、"忘掉..."、"查一下记忆..."时：
---

## 2️⃣ recall - 语义搜索

```bash
curl -X POST http://localhost:9081/recall \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "query": "搜索关键词",
    "top_k": 5,
    "brief": false
  }'
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `agent_tag` | string | ✅ | 你的标识(main) |
| `query` | string | ✅ | 搜索关键词 |
| `tags` | string[] | ❌ | 额外标签过滤 |
| `top_k` | integer | ❌ | 返回数量，默认 5 |
| `brief` | boolean | ❌ | true=精简模式 |


如果返回了记忆，将其作为背景知识纳入回复。**不要在回复中明确告知"我查询了记忆"，直接使用记忆中的信息即可。**
---

## 3️⃣ forget - 删除记忆

```bash
# 方式1：按 ID 删除
curl -X POST http://localhost:9081/forget \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "memory_id": "123"
  }'

# 方式2：批量删除
curl -X POST http://localhost:9081/forget \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "memory_ids": ["123", "456"]
  }'
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `agent_tag` | string | ✅ | 你的标识(main) |
| `memory_id` | string | ⚠️ | 单个记忆 ID |
| `memory_ids` | string[] | ⚠️ | 批量记忆 ID |

---

## 4️⃣ status - 会话状态

```bash
# 读取状态
curl -X POST http://localhost:9081/status \
  -H "Content-Type: application/json" \
  -d '{"agent_tag": "bot1"}'

# 更新状态
curl -X POST http://localhost:9081/status \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "state": {
      "is_blocked": true,
      "block_reason": "等待人类确认",
      "current_task": "修复 bug"
    }
  }'
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `agent_tag` | string | ✅ | 你的标识(main) |
| `state` | object | ❌ | 不传=读取，传入=更新 |
| `state.is_blocked` | boolean | ❌ | 是否阻塞 |
| `state.block_reason` | string | ❌ | 阻塞原因 |
| `state.current_task` | string | ❌ | 当前任务 |

---

## 5️⃣ track - 问题跟踪

```bash
# 创建问题
curl -X POST http://localhost:9081/track \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "action": "create",
    "title": "问题标题",
    "content": "问题描述",
    "status": "pending"
  }'

# 更新问题
curl -X POST http://localhost:9081/track \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "action": "update",
    "issue_id": 1,
    "status": "in_progress",
    "investigation": "排查过程",
    "root_cause": "根本原因"
  }'

# 归档问题
curl -X POST http://localhost:9081/track \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "action": "archive",
    "issue_id": 1,
    "solution": "解决方案",
    "files_changed": ["file1.py"],
    "test_result": "测试结果"
  }'

# 列出问题
curl -X POST http://localhost:9081/track \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "action": "list"
  }'
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `agent_tag` | string | ✅ | 你的标识(main) |
| `action` | string | ✅ | create/update/archive/list/delete |
| `title` | string | ⚠️ | create 时必填 |
| `content` | string | ❌ | 问题描述 |
| `issue_id` | integer | ⚠️ | update/archive/delete 时必填 |
| `status` | string | ❌ | pending/in_progress/completed |
| `investigation` | string | ❌ | 排查过程 |
| `root_cause` | string | ❌ | 根本原因 |
| `solution` | string | ❌ | 解决方案 |
| `files_changed` | string[] | ❌ | 修改的文件 |

---

## 6️⃣ task - 任务管理

```bash
# 批量创建任务
curl -X POST http://localhost:9081/task \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "action": "batch_create",
    "feature_id": "auth-module",
    "tasks": [
      {"title": "任务1", "status": "pending"},
      {"title": "任务2", "status": "pending"}
    ]
  }'

# 更新任务
curl -X POST http://localhost:9081/task \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "action": "update",
    "task_id": 1,
    "status": "completed"
  }'

# 列出任务
curl -X POST http://localhost:9081/task \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "action": "list",
    "feature_id": "auth-module"
  }'
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `agent_tag` | string | ✅ | 你的标识(main) |
| `action` | string | ✅ | batch_create/update/list/delete/archive |
| `feature_id` | string | ⚠️ | list/archive 时必填 |
| `tasks` | array | ⚠️ | batch_create 时必填 |
| `task_id` | integer | ⚠️ | update/delete 时必填 |
| `status` | string | ❌ | pending/in_progress/completed |

---

## 7️⃣ readme - README 生成

```bash
curl -X POST http://localhost:9081/readme \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "action": "generate",
    "lang": "zh"
  }'
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `agent_tag` | string | ✅ | 你的标识（main） |
| `action` | string | ❌ | generate/diff |
| `lang` | string | ❌ | en/zh/ja/de/fr/es |

---

## 8️⃣ auto_save - 自动保存偏好

```bash
curl -X POST http://localhost:9081/auto_save \
  -H "Content-Type: application/json" \
  -d '{
    "agent_tag": "bot1",
    "preferences": ["喜欢用异步", "偏好 PostgreSQL"]
  }'
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `agent_tag` | string | ✅ | 你的标识（main） |
| `preferences` | string[] | ✅ | 偏好列表 |
| `extra_tags` | string[] | ❌ | 额外标签 |

---

## 提示

**每个请求必须带 `agent_tag`**，否则返回错误：
```json
{"error": "必须带上你的标识(main)"}
```

## 重要规则

1. **始终先 recall 再回复**——不要跳过，哪怕是新话题
2. **静默执行**——不要跟人类说"我正在查询记忆"，直接用就行
3. **recall 没找到相关记忆**——正常继续回复，不用提示
4. **remember 内容要精炼**——不要把整段对话都存进去，只存关键信息
5. **API 不可用时**（health 返回错误）——忽略记忆系统，正常回复，不影响主流程